import React from 'react';

const AccordionTwo = () => {
    return (
        <div>
            
        </div>
    )
}

export default AccordionTwo
